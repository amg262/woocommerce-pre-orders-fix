=== WooCommerce Pre-Orders ===
Author: woothemes
Requires at least: 4.0
Tested up to: 4.2.2
Stable tag: 1.4.4

== Description ==

Sell pre-orders for products in your WooCommerce store

See http://docs.woothemes.com/document/pre-orders/ for full documentation.
